# Personal Finance Tracker

A simple command-line personal finance tracker built in Python. Track your income and expenses, filter transactions, and get a financial summary — all from your terminal.

## Features

- **Add transactions** — Record income and expenses with category, date, and description
- **List transactions** — View all transactions or filter by type (income/expense) or category
- **Financial summary** — Get an overview of total income, expenses, and balance
- **Persistent storage** — Transactions are saved to a JSON file
- **Zero dependencies** — Uses only Python standard library modules

## Requirements

- Python 3.8 or higher

## Installation

No installation required! Simply clone or download the project and run it directly.

```bash
# Navigate to the project directory
cd personal_finance_tracker

# Run the tracker
python -m finance_tracker
```

## Usage

### Add a Transaction

```bash
# Add an income transaction
python -m finance_tracker add income 5000 --category Salary --date 2026-04-01 --description "Monthly salary"

# Add an expense transaction (date defaults to today)
python -m finance_tracker add expense 25.50 --category Food --description "Grocery shopping"

# Add an expense with a custom date
python -m finance_tracker add expense 15.00 --category Transport --date 2026-04-20 --description "Bus fare"
```

**Arguments:**
| Argument | Required | Description |
|----------|----------|-------------|
| `type` | Yes | Transaction type: `income` or `expense` |
| `amount` | Yes | Amount (positive number) |
| `category` | Yes | Category (e.g., Food, Salary, Transport) |
| `--date` | No | Date in YYYY-MM-DD format (defaults to today) |
| `--description` | No | Optional description |

### List Transactions

```bash
# List all transactions (last 20)
python -m finance_tracker list

# Filter by type
python -m finance_tracker list --type income

# Filter by category
python -m finance_tracker list --category Food

# Increase limit
python -m finance_tracker list --limit 50
```

### Show Summary

```bash
python -m finance_tracker summary
```

This displays:
- Total income
- Total expenses
- Net balance
- Transaction count

### Custom Storage Path

By default, transactions are stored in `~/.finance_tracker/transactions.json`. You can specify a custom path:

```bash
python -m finance_tracker --storage /path/to/my_transactions.json add income 3000 --category Salary
```

## Project Structure

```
personal_finance_tracker/
├── README.md                 # This file
├── finance_tracker/
│   ├── __init__.py           # Package initialization
│   ├── __main__.py           # Module entry point
│   ├── cli.py                # CLI argument parsing
│   ├── commands.py           # Command handlers (add, list, summary)
│   ├── models.py             # Transaction data model
│   └── storage.py            # JSON-based storage layer
└── tests/
    ├── __init__.py           # Tests package
    └── test_transactions.py  # Unit tests
```

## Running Tests

```bash
cd personal_finance_tracker
python -m pytest tests/test_transactions.py -v

# Or using unittest
python -m unittest discover tests -v
```

## Example Output

```
$ python -m finance_tracker add income 5000 --category Salary --date 2026-04-01 --description "Monthly salary"
Transaction added successfully!
  ID:         a3f2b1c4
  Date:       2026-04-01
  Type:       income
  Category:   Salary
  Amount:     $5000.00
  Description: Monthly salary

$ python -m finance_tracker list

Date         Type     Category               Amount  Description
----------------------------------------------------------------------
[2026-04-01] INCOME   | Salary            |  +5000.00 | Monthly salary
----------------------------------------------------------------------
Total Income:      $5000.00
Total Expenses:   $   0.00
Balance:           $5000.00

Showing 1 transaction(s)
```

## Data Model

Each transaction has the following fields:

| Field | Type | Description |
|-------|------|-------------|
| `id` | string | Unique 8-character identifier (auto-generated) |
| `date` | date | Transaction date (defaults to today) |
| `type` | string | Either `income` or `expense` |
| `category` | string | Transaction category |
| `amount` | float | Positive number |
| `description` | string | Optional description |

## License

This project is open source and available for personal use.