"""Tests for the add transaction functionality."""

import json
import os
import tempfile
import unittest
from datetime import date
from unittest.mock import patch, MagicMock

# Import the module under test
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from finance_tracker.models import Transaction
from finance_tracker.commands import add_transaction
from finance_tracker.storage import Storage, StorageError


class TestTransactionModel(unittest.TestCase):
    """Tests for the Transaction data model."""

    def test_create_valid_income_transaction(self):
        """Test creating a valid income transaction."""
        tx = Transaction(
            type="income",
            category="Salary",
            amount=5000.00,
            description="Monthly salary",
        )
        self.assertEqual(tx.type, "income")
        self.assertEqual(tx.category, "Salary")
        self.assertEqual(tx.amount, 5000.00)
        self.assertEqual(tx.description, "Monthly salary")
        self.assertIsInstance(tx.date, date)
        self.assertIsNotNone(tx.id)

    def test_create_valid_expense_transaction(self):
        """Test creating a valid expense transaction."""
        tx = Transaction(
            type="expense",
            category="Food",
            amount=25.50,
            date=date(2026, 4, 15),
            description="Grocery shopping",
        )
        self.assertEqual(tx.type, "expense")
        self.assertEqual(tx.amount, 25.50)
        self.assertEqual(tx.date, date(2026, 4, 15))

    def test_invalid_transaction_type(self):
        """Test that invalid transaction type raises ValueError."""
        with self.assertRaises(ValueError) as context:
            Transaction(type="savings", category="Bank", amount=100.00)
        self.assertIn("income", str(context.exception))

    def test_invalid_amount_zero(self):
        """Test that zero amount raises ValueError."""
        with self.assertRaises(ValueError) as context:
            Transaction(type="expense", category="Food", amount=0)
        self.assertIn("positive", str(context.exception).lower())

    def test_invalid_amount_negative(self):
        """Test that negative amount raises ValueError."""
        with self.assertRaises(ValueError) as context:
            Transaction(type="expense", category="Food", amount=-50.00)
        self.assertIn("positive", str(context.exception).lower())

    def test_empty_category(self):
        """Test that empty category raises ValueError."""
        with self.assertRaises(ValueError) as context:
            Transaction(type="expense", category="", amount=50.00)
        self.assertIn("empty", str(context.exception).lower())

    def test_to_dict(self):
        """Test converting a transaction to a dictionary."""
        tx = Transaction(
            type="expense",
            category="Transport",
            amount=15.00,
            date=date(2026, 4, 20),
            description="Bus fare",
            id="abc12345",
        )
        data = tx.to_dict()
        self.assertEqual(data["id"], "abc12345")
        self.assertEqual(data["date"], "2026-04-20")
        self.assertEqual(data["type"], "expense")
        self.assertEqual(data["category"], "Transport")
        self.assertEqual(data["amount"], 15.00)
        self.assertEqual(data["description"], "Bus fare")

    def test_from_dict(self):
        """Test creating a transaction from a dictionary."""
        data = {
            "id": "xyz78901",
            "date": "2026-04-10",
            "type": "income",
            "category": "Freelance",
            "amount": 1200.75,
            "description": "Web design project",
        }
        tx = Transaction.from_dict(data)
        self.assertEqual(tx.id, "xyz78901")
        self.assertEqual(tx.date, date(2026, 4, 10))
        self.assertEqual(tx.type, "income")
        self.assertEqual(tx.category, "Freelance")
        self.assertEqual(tx.amount, 1200.75)
        self.assertEqual(tx.description, "Web design project")

    def test_from_dict_roundtrip(self):
        """Test that to_dict and from_dict are inverses."""
        original = Transaction(
            type="expense",
            category="Utilities",
            amount=85.30,
            date=date(2026, 3, 1),
            description="Electric bill",
            id="round1234",
        )
        data = original.to_dict()
        restored = Transaction.from_dict(data)
        self.assertEqual(restored.id, original.id)
        self.assertEqual(restored.date, original.date)
        self.assertEqual(restored.type, original.type)
        self.assertEqual(restored.category, original.category)
        self.assertAlmostEqual(restored.amount, original.amount)
        self.assertEqual(restored.description, original.description)

    def test_string_representation(self):
        """Test the __str__ method."""
        tx = Transaction(
            type="income",
            category="Salary",
            amount=3000.00,
            date=date(2026, 4, 1),
            description="April salary",
        )
        tx_str = str(tx)
        self.assertIn("2026-04-01", tx_str)
        self.assertIn("INCOME", tx_str)
        self.assertIn("Salary", tx_str)
        self.assertIn("3000.00", tx_str)
        self.assertIn("April salary", tx_str)


class TestAddTransactionCommand(unittest.TestCase):
    """Tests for the add_transaction command function."""

    def setUp(self):
        """Set up a temporary storage file for each test."""
        self.temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False)
        self.temp_file.close()
        self.temp_path = self.temp_file.name

    def tearDown(self):
        """Clean up the temporary storage file."""
        if os.path.exists(self.temp_path):
            os.unlink(self.temp_path)

    def test_add_income_transaction(self):
        """Test adding an income transaction."""
        tx = add_transaction(
            tx_type="income",
            amount=5000.00,
            category="Salary",
            date_str="2026-04-01",
            description="Monthly salary",
            storage_path=self.temp_path,
        )
        self.assertEqual(tx.type, "income")
        self.assertEqual(tx.category, "Salary")
        self.assertEqual(tx.amount, 5000.00)
        self.assertEqual(tx.date, date(2026, 4, 1))
        self.assertEqual(tx.description, "Monthly salary")

    def test_add_expense_transaction(self):
        """Test adding an expense transaction."""
        tx = add_transaction(
            tx_type="expense",
            amount=25.50,
            category="Food",
            date_str="2026-04-15",
            description="Lunch",
            storage_path=self.temp_path,
        )
        self.assertEqual(tx.type, "expense")
        self.assertEqual(tx.amount, 25.50)
        self.assertEqual(tx.category, "Food")

    def test_add_transaction_defaults_to_today(self):
        """Test that transaction date defaults to today when not provided."""
        tx = add_transaction(
            tx_type="expense",
            amount=10.00,
            category="Snacks",
            storage_path=self.temp_path,
        )
        self.assertEqual(tx.date, date.today())

    def test_add_transaction_generates_id(self):
        """Test that a unique ID is generated for each transaction."""
        tx1 = add_transaction(
            tx_type="expense",
            amount=10.00,
            category="Food",
            storage_path=self.temp_path,
        )
        tx2 = add_transaction(
            tx_type="expense",
            amount=20.00,
            category="Transport",
            storage_path=self.temp_path,
        )
        self.assertNotEqual(tx1.id, tx2.id)
        self.assertEqual(len(tx1.id), 8)

    def test_add_multiple_transactions(self):
        """Test adding multiple transactions and verifying they persist."""
        add_transaction("expense", 25.50, "Food", "2026-04-15", "Lunch", self.temp_path)
        add_transaction("income", 5000.00, "Salary", "2026-04-01", "Monthly pay", self.temp_path)
        add_transaction("expense", 15.00, "Transport", "2026-04-16", "Bus", self.temp_path)

        storage = Storage(filepath=self.temp_path)
        transactions = storage.load_all()
        self.assertEqual(len(transactions), 3)

    def test_add_invalid_type(self):
        """Test that adding a transaction with invalid type raises ValueError."""
        with self.assertRaises(ValueError):
            add_transaction(
                tx_type="savings",
                amount=100.00,
                category="Bank",
                storage_path=self.temp_path,
            )

    def test_add_invalid_amount_zero(self):
        """Test that adding a transaction with zero amount raises ValueError."""
        with self.assertRaises(ValueError):
            add_transaction(
                tx_type="expense",
                amount=0,
                category="Food",
                storage_path=self.temp_path,
            )

    def test_add_invalid_amount_negative(self):
        """Test that adding a transaction with negative amount raises ValueError."""
        with self.assertRaises(ValueError):
            add_transaction(
                tx_type="expense",
                amount=-50.00,
                category="Food",
                storage_path=self.temp_path,
            )

    def test_add_invalid_date_format(self):
        """Test that an invalid date format raises ValueError."""
        with self.assertRaises(ValueError):
            add_transaction(
                tx_type="expense",
                amount=50.00,
                category="Food",
                date_str="04/15/2026",
                storage_path=self.temp_path,
            )

    def test_add_empty_category(self):
        """Test that adding a transaction with empty category raises ValueError."""
        with self.assertRaises(ValueError):
            add_transaction(
                tx_type="expense",
                amount=50.00,
                category="  ",
                storage_path=self.temp_path,
            )

    def test_add_persists_to_json(self):
        """Test that the transaction is correctly persisted to the JSON file."""
        add_transaction(
            "income", 3000.00, "Salary", "2026-04-01", "April salary", self.temp_path
        )

        with open(self.temp_path, 'r') as f:
            data = json.load(f)

        self.assertEqual(len(data), 1)
        self.assertEqual(data[0]["type"], "income")
        self.assertEqual(data[0]["amount"], 3000.00)
        self.assertEqual(data[0]["category"], "Salary")
        self.assertEqual(data[0]["date"], "2026-04-01")
        self.assertEqual(data[0]["description"], "April salary")

    def test_add_with_whitespace_category_stripped(self):
        """Test that whitespace in category is stripped."""
        tx = add_transaction(
            tx_type="expense",
            amount=50.00,
            category="  Food  ",
            storage_path=self.temp_path,
        )
        self.assertEqual(tx.category, "Food")


class TestStorageLayer(unittest.TestCase):
    """Tests for the Storage class."""

    def setUp(self):
        """Set up a temporary storage file."""
        self.temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False)
        self.temp_file.close()
        self.storage = Storage(filepath=self.temp_file.name)

    def tearDown(self):
        """Clean up the temporary file."""
        if os.path.exists(self.temp_file.name):
            os.unlink(self.temp_file.name)

    def test_load_all_empty(self):
        """Test loading from an empty storage file."""
        transactions = self.storage.load_all()
        self.assertEqual(len(transactions), 0)

    def test_save_and_load(self):
        """Test saving and loading transactions."""
        tx = Transaction(
            type="income",
            category="Salary",
            amount=5000.00,
            date=date(2026, 4, 1),
        )
        self.storage.add(tx)
        loaded = self.storage.load_all()
        self.assertEqual(len(loaded), 1)
        self.assertEqual(loaded[0].type, "income")
        self.assertEqual(loaded[0].amount, 5000.00)

    def test_find_by_type_income(self):
        """Test filtering transactions by income type."""
        self.storage.add(Transaction("income", "Salary", 5000.00))
        self.storage.add(Transaction("expense", "Food", 25.00))
        self.storage.add(Transaction("income", "Freelance", 1000.00))

        results = self.storage.find_by_type("income")
        self.assertEqual(len(results), 2)
        for tx in results:
            self.assertEqual(tx.type, "income")

    def test_find_by_type_expense(self):
        """Test filtering transactions by expense type."""
        self.storage.add(Transaction("income", "Salary", 5000.00))
        self.storage.add(Transaction("expense", "Food", 25.00))
        self.storage.add(Transaction("expense", "Transport", 15.00))

        results = self.storage.find_by_type("expense")
        self.assertEqual(len(results), 2)

    def test_find_by_category(self):
        """Test filtering transactions by category."""
        self.storage.add(Transaction("expense", "Food", 25.00))
        self.storage.add(Transaction("expense", "Food", 15.00))
        self.storage.add(Transaction("expense", "Transport", 10.00))

        results = self.storage.find_by_category("Food")
        self.assertEqual(len(results), 2)

    def test_find_by_category_case_insensitive(self):
        """Test that category filtering is case-insensitive."""
        self.storage.add(Transaction("expense", "food", 25.00))
        self.storage.add(Transaction("expense", "Food", 15.00))
        self.storage.add(Transaction("expense", "Transport", 10.00))

        results = self.storage.find_by_category("FOOD")
        self.assertEqual(len(results), 2)

    def test_get_summary(self):
        """Test getting a financial summary."""
        self.storage.add(Transaction("income", "Salary", 5000.00))
        self.storage.add(Transaction("income", "Freelance", 1000.00))
        self.storage.add(Transaction("expense", "Food", 100.00))
        self.storage.add(Transaction("expense", "Transport", 50.00))

        summary = self.storage.get_summary()
        self.assertAlmostEqual(summary["total_income"], 6000.00)
        self.assertAlmostEqual(summary["total_expenses"], 150.00)
        self.assertAlmostEqual(summary["balance"], 5850.00)
        self.assertEqual(summary["transaction_count"], 4)


if __name__ == "__main__":
    unittest.main()