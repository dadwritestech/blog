"""Personal Finance Tracker - A command-line personal finance management tool."""

__version__ = "1.0.0"