"""CLI command handlers for the Personal Finance Tracker."""

from datetime import datetime
from typing import List, Optional
from pathlib import Path
from .models import Transaction
from .storage import Storage


def add_transaction(
    tx_type: str,
    amount: float,
    category: str,
    date_str: Optional[str] = None,
    description: str = "",
    storage_path: Optional[Path] = None,
) -> Transaction:
    """Add a new transaction to the finance tracker.

    Args:
        tx_type: Either 'income' or 'expense'.
        amount: The transaction amount (positive number).
        category: The transaction category (e.g., 'Food', 'Salary').
        date_str: Optional date string in YYYY-MM-DD format. Defaults to today.
        description: Optional description of the transaction.
        storage_path: Optional custom path for the storage file.

    Returns:
        The created Transaction instance.

    Raises:
        ValueError: If the transaction data is invalid.
        StorageError: If the storage operation fails.
    """
    # Parse the date if provided
    if date_str:
        try:
            tx_date = datetime.strptime(date_str, "%Y-%m-%d").date()
        except ValueError:
            raise ValueError("Date must be in YYYY-MM-DD format")
    else:
        tx_date = None

    # Create the transaction (date will default to today in the model if not provided)
    transaction = Transaction(
        type=tx_type,
        category=category.strip(),
        amount=amount,
        description=description.strip(),
    )
    # Override date if explicitly provided
    if tx_date is not None:
        transaction.date = tx_date

    # Save to storage
    storage = Storage(filepath=storage_path)
    storage.add(transaction)

    return transaction


def list_transactions(
    tx_type: Optional[str] = None,
    category: Optional[str] = None,
    limit: int = 20,
    storage_path: Optional[Path] = None,
) -> List[Transaction]:
    """List transactions with optional filters.

    Args:
        tx_type: Optional filter by type ('income' or 'expense').
        category: Optional filter by category name.
        limit: Maximum number of transactions to return (default 20).
        storage_path: Optional custom path for the storage file.

    Returns:
        A list of Transaction instances, most recent first.
    """
    storage = Storage(filepath=storage_path)

    if tx_type:
        transactions = storage.find_by_type(tx_type)
    elif category:
        transactions = storage.find_by_category(category)
    else:
        transactions = storage.load_all()

    # Sort by date (most recent first), then by creation order
    transactions.sort(key=lambda t: t.date, reverse=True)

    return transactions[:limit]


def show_summary(storage_path: Optional[Path] = None) -> dict:
    """Show a financial summary.

    Args:
        storage_path: Optional custom path for the storage file.

    Returns:
        A dictionary with total_income, total_expenses, balance, and transaction_count.
    """
    storage = Storage(filepath=storage_path)
    return storage.get_summary()