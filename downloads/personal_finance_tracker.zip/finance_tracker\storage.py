"""JSON-based storage layer for the Personal Finance Tracker."""

import json
import os
from pathlib import Path
from typing import List, Optional
from .models import Transaction


class StorageError(Exception):
    """Base exception for storage-related errors."""
    pass


class Storage:
    """Manages persistence of transactions to a JSON file.

    Attributes:
        filepath: Path to the JSON file where transactions are stored.
    """

    def __init__(self, filepath: Optional[Path] = None) -> None:
        """Initialize the storage with a file path.

        Args:
            filepath: Path to the JSON file. Defaults to ~/.finance_tracker/transactions.json.
        """
        if filepath is None:
            home = Path.home()
            filepath = home / ".finance_tracker" / "transactions.json"
        self.filepath = Path(filepath)
        self._ensure_storage_exists()

    def _ensure_storage_exists(self) -> None:
        """Create the storage directory and an empty JSON file if they don't exist."""
        self.filepath.parent.mkdir(parents=True, exist_ok=True)
        if not self.filepath.exists():
            self.filepath.write_text("[]", encoding="utf-8")

    def load_all(self) -> List[Transaction]:
        """Load all transactions from the storage file.

        Returns:
            A list of Transaction instances.
        """
        try:
            content = self.filepath.read_text(encoding="utf-8").strip()
            # Handle empty files
            if not content:
                return []
            data = json.loads(content)
        except (json.JSONDecodeError, OSError) as e:
            raise StorageError(f"Failed to load transactions: {e}")

        transactions = []
        for item in data:
            try:
                transactions.append(Transaction.from_dict(item))
            except (ValueError, KeyError) as e:
                # Skip malformed entries
                continue
        return transactions

    def save_all(self, transactions: List[Transaction]) -> None:
        """Save all transactions to the storage file.

        Args:
            transactions: A list of Transaction instances to persist.
        """
        try:
            data = [t.to_dict() for t in transactions]
            self.filepath.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except OSError as e:
            raise StorageError(f"Failed to save transactions: {e}")

    def add(self, transaction: Transaction) -> None:
        """Add a single transaction to the storage.

        Args:
            transaction: The Transaction instance to add.
        """
        transactions = self.load_all()
        transactions.append(transaction)
        self.save_all(transactions)

    def find_by_type(self, tx_type: str) -> List[Transaction]:
        """Find transactions by their type.

        Args:
            tx_type: Either 'income' or 'expense'.

        Returns:
            A list of matching Transaction instances.
        """
        return [t for t in self.load_all() if t.type == tx_type]

    def find_by_category(self, category: str) -> List[Transaction]:
        """Find transactions by their category.

        Args:
            category: The category string to match.

        Returns:
            A list of matching Transaction instances.
        """
        return [t for t in self.load_all() if t.category.lower() == category.lower()]

    def get_summary(self) -> dict:
        """Get a summary of all transactions.

        Returns:
            A dictionary with total income, total expenses, and balance.
        """
        transactions = self.load_all()
        total_income = sum(t.amount for t in transactions if t.type == "income")
        total_expenses = sum(t.amount for t in transactions if t.type == "expense")
        return {
            "total_income": total_income,
            "total_expenses": total_expenses,
            "balance": total_income - total_expenses,
            "transaction_count": len(transactions),
        }