"""CLI argument parsing for the Personal Finance Tracker."""

import argparse
import sys
from typing import Optional
from pathlib import Path
from .commands import add_transaction, list_transactions, show_summary
from .models import Transaction


def parse_add(args: argparse.Namespace) -> None:
    """Handle the 'add' subcommand.

    Args:
        args: Parsed argparse namespace.
    """
    try:
        transaction = add_transaction(
            tx_type=args.type,
            amount=float(args.amount),
            category=args.category,
            date_str=args.date,
            description=args.description,
            storage_path=args.storage,
        )
        print(f"Transaction added successfully!")
        print(f"  ID:      {transaction.id}")
        print(f"  Date:    {transaction.date}")
        print(f"  Type:    {transaction.type}")
        print(f"  Category: {transaction.category}")
        print(f"  Amount:  ${transaction.amount:.2f}")
        if transaction.description:
            print(f"  Description: {transaction.description}")
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def parse_list(args: argparse.Namespace) -> None:
    """Handle the 'list' subcommand.

    Args:
        args: Parsed argparse namespace.
    """
    try:
        transactions = list_transactions(
            tx_type=args.type,
            category=args.category,
            limit=args.limit,
            storage_path=args.storage,
        )

        if not transactions:
            print("No transactions found.")
            return

        # Print header
        print(f"\n{'Date':<12} {'Type':<8} {'Category':<15} {'Amount':>12}  Description")
        print("-" * 70)

        total_income = 0.0
        total_expenses = 0.0

        for tx in transactions:
            print(str(tx))
            if tx.type == "income":
                total_income += tx.amount
            else:
                total_expenses += tx.amount

        # Print summary
        print("-" * 70)
        print(f"Total Income:  ${total_income:>10.2f}")
        print(f"Total Expenses: ${total_expenses:>10.2f}")
        balance = total_income - total_expenses
        print(f"Balance:       ${balance:>10.2f}")
        print(f"\nShowing {len(transactions)} transaction(s)")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def parse_summary(args: argparse.Namespace) -> None:
    """Handle the 'summary' subcommand.

    Args:
        args: Parsed argparse namespace.
    """
    try:
        summary = show_summary(storage_path=args.storage)
        print("\n=== Financial Summary ===")
        print(f"Total Income:    ${summary['total_income']:>10.2f}")
        print(f"Total Expenses:  ${summary['total_expenses']:>10.2f}")
        print(f"Balance:         ${summary['balance']:>10.2f}")
        print(f"Transactions:    {summary['transaction_count']}")
        print("=========================")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def create_parser() -> argparse.ArgumentParser:
    """Create and configure the argument parser.

    Returns:
        An ArgumentParser instance configured with all subcommands.
    """
    parser = argparse.ArgumentParser(
        prog="finance_tracker",
        description="Personal Finance Tracker - Track your income and expenses from the command line.",
    )
    parser.add_argument(
        "--storage",
        type=str,
        help="Custom path to the transactions JSON file",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # 'add' subcommand
    add_parser = subparsers.add_parser("add", help="Add a new transaction")
    add_parser.add_argument(
        "type",
        choices=["income", "expense"],
        help="Transaction type: income or expense",
    )
    add_parser.add_argument(
        "amount",
        type=float,
        help="Transaction amount (positive number)",
    )
    add_parser.add_argument(
        "category",
        type=str,
        help="Transaction category (e.g., Food, Salary, Transport)",
    )
    add_parser.add_argument(
        "--date",
        type=str,
        default=None,
        help="Transaction date in YYYY-MM-DD format (defaults to today)",
    )
    add_parser.add_argument(
        "--description",
        type=str,
        default="",
        help="Optional description of the transaction",
    )
    add_parser.set_defaults(func=parse_add)

    # 'list' subcommand
    list_parser = subparsers.add_parser("list", help="List transactions")
    list_parser.add_argument(
        "--type",
        choices=["income", "expense"],
        default=None,
        help="Filter by transaction type",
    )
    list_parser.add_argument(
        "--category",
        type=str,
        default=None,
        help="Filter by category",
    )
    list_parser.add_argument(
        "--limit",
        type=int,
        default=20,
        help="Maximum number of transactions to display (default: 20)",
    )
    list_parser.set_defaults(func=parse_list)

    # 'summary' subcommand
    summary_parser = subparsers.add_parser("summary", help="Show financial summary")
    summary_parser.set_defaults(func=parse_summary)

    return parser


def main() -> None:
    """Entry point for the CLI application."""
    parser = create_parser()
    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    args.func(args)