"""Entry point for running the finance tracker as a module."""

import sys
from .cli import main


def cli() -> None:
    """Convenience entry point for console scripts."""
    main()


if __name__ == "__main__":
    main()