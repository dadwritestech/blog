"""Transaction data model for the Personal Finance Tracker."""

import uuid
from datetime import date, datetime
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Transaction:
    """Represents a single financial transaction.

    Attributes:
        id: Unique identifier for the transaction.
        date: The date of the transaction.
        type: Either 'income' or 'expense'.
        category: The transaction category (e.g., 'Food', 'Salary').
        amount: The transaction amount (must be positive).
        description: Optional description of the transaction.
    """

    type: str
    category: str
    amount: float
    date: date = field(default_factory=date.today)
    description: str = ""
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])

    def __post_init__(self) -> None:
        """Validate transaction fields after initialization."""
        if self.type not in ("income", "expense"):
            raise ValueError("Transaction type must be 'income' or 'expense'")
        if self.amount <= 0:
            raise ValueError("Amount must be a positive number")
        if not self.category or not self.category.strip():
            raise ValueError("Category cannot be empty")

    def to_dict(self) -> dict:
        """Convert the transaction to a dictionary for serialization.

        Returns:
            A dictionary representation of the transaction.
        """
        return {
            "id": self.id,
            "date": self.date.isoformat(),
            "type": self.type,
            "category": self.category,
            "amount": self.amount,
            "description": self.description,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Transaction":
        """Create a Transaction from a dictionary (deserialization).

        Args:
            data: A dictionary with transaction fields.

        Returns:
            A Transaction instance.
        """
        return cls(
            id=data.get("id", str(uuid.uuid4())[:8]),
            date=datetime.fromisoformat(data["date"]).date() if isinstance(data["date"], str) else data["date"],
            type=data["type"],
            category=data["category"],
            amount=float(data["amount"]),
            description=data.get("description", ""),
        )

    def __str__(self) -> str:
        """Return a human-readable string representation of the transaction."""
        sign = "+" if self.type == "income" else "-"
        return (
            f"[{self.date}] {self.type.upper():7s} | {self.category:15s} | "
            f"{sign}{self.amount:>10.2f} | {self.description}"
        )